# workshopdemo
This is MERN stack todo application, made for a workshop
